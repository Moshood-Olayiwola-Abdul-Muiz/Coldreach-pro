import { getStore } from '@netlify/blobs';

export const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  const { query, location, email } = JSON.parse(event.body || "{}");

  if (!email) {
    return { statusCode: 400, body: JSON.stringify({ error: "Email is required to track usage" }) };
  }

  try {
    // Check daily limit using Netlify Blobs
    const store = getStore('discovery-usage');
    const today = new Date().toISOString().split('T')[0];
    const usageKey = `${email}_${today}`;
    
    const usage = await store.get(usageKey, { type: 'json' });
    if (usage && usage.count >= 1) {
      return { 
        statusCode: 429, 
        body: JSON.stringify({ error: "Daily limit reached. Please upgrade to generate unlimited leads." }) 
      };
    }

    // Connect to Supabase
    const SUPABASE_URL = "https://snriiilztnuxgnwdoran.supabase.co";
    const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNucmlpaWx6dG51eGdud2RvcmFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY1MzQ5NTAsImV4cCI6MjA5MjExMDk1MH0.qLeqFhWRHlh1p3Tza2K3XrNOpKvxNnuorOQOt9IgAvs";
    
    // Attempt to fetch from a 'leads' table in Supabase
    // We pass query as a text search if possible, or just fetch random for now.
    const supabaseResponse = await fetch(`${SUPABASE_URL}/rest/v1/leads?select=*&limit=50`, {
      headers: {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
        "Content-Type": "application/json"
      }
    });

    let leads = [];
    if (supabaseResponse.ok) {
      leads = await supabaseResponse.json();
    } else {
      console.warn("Supabase fetch failed, returning mock leads or empty:", await supabaseResponse.text());
      // If table doesn't exist yet, return some mock leads to avoid breaking the UI for the user.
      leads = [
        { id: "1", name: "Tech Solutions Inc", address: "123 Innovation Dr", email: "contact@techsolutions.test", phone: "555-0101", website: "techsolutions.test" },
        { id: "2", name: "Global Reach", address: "456 Market St", email: "info@globalreach.test", phone: "555-0202", website: "globalreach.test" }
      ];
    }

    // Increment usage
    await store.setJSON(usageKey, { count: 1 });

    return {
      statusCode: 200,
      body: JSON.stringify(leads)
    };
  } catch (error) {
    console.error("Discovery error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};