import { LeadStatus } from '../types.ts';

let workerInterval: any = null;

export const startCampaignWorker = () => {
  if (workerInterval) {
    clearInterval(workerInterval);
  }

  const runWorker = async () => {
    const state = JSON.parse(localStorage.getItem('cr_campaign_state') || '{}');
    if (!state.running) {
      if (workerInterval) clearInterval(workerInterval);
      return;
    }

    const now = Date.now();
    const intervalMs = (state.interval || 300) * 1000;
    
    if (state.lastSent && now - state.lastSent < intervalMs) {
      return; // Not time yet
    }

    // --- PROFESSIONAL WARMUP LOGIC ---
    const warmingAccounts = accounts.filter((acc: any) => acc.is_warming_up && acc.access_token);
    if (warmingAccounts.length > 0) {
      // 10% chance per cycle to send a warmup email to simulate human behavior
      if (Math.random() < 0.1) {
        const sender = warmingAccounts[Math.floor(Math.random() * warmingAccounts.length)];
        const recipient = accounts[Math.floor(Math.random() * accounts.length)]; // send to any owned account
        
        if (sender.id !== recipient.id) {
          const addActivity = (msg: string, type: 'info' | 'success' | 'error' | 'reply' | 'warmup' = 'info') => {
            const logs = JSON.parse(localStorage.getItem('cr_campaign_logs') || '[]');
            logs.unshift({ id: Date.now(), msg, type, time: new Date().toLocaleTimeString() });
            localStorage.setItem('cr_campaign_logs', JSON.stringify(logs.slice(0, 50)));
            window.dispatchEvent(new Event('cr_campaign_logs_updated'));
          };

          const subjects = ["Quick question", "Following up", "Checking in", "Meeting later?", "Thoughts on this?"];
          const bodies = [
            "Hey, just wanted to see if you were available later this week to chat.",
            "Hi there, following up on our previous conversation. Let me know!",
            "Hope you're having a good week. Can we schedule a brief call?",
            "I'm reviewing the documents and had a quick question. Give me a call when free.",
            "Just checking in to see if everything is on track for Friday."
          ];
          
          const subject = subjects[Math.floor(Math.random() * subjects.length)];
          const body = bodies[Math.floor(Math.random() * bodies.length)] + "\n\nBest,\n" + sender.email.split('@')[0];

          addActivity(`[Warmup] Sending professional interaction from ${sender.email} to ${recipient.email}`, 'info');

          fetch('/.netlify/functions/send-email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              access_token: sender.access_token,
              refresh_token: sender.refresh_token,
              expires_at: sender.expires_at,
              to: recipient.email,
              subject: subject,
              body: body
            })
          }).catch(() => {}); // silent fail for warmup
        }
      }
    }
    // --- END WARMUP LOGIC ---


    // Reload fresh data from localStorage
    const accounts = JSON.parse(localStorage.getItem('coldreach_accounts') || '[]');
    const activeAccounts = accounts.filter((acc: any) => !acc.is_warming_up && acc.access_token);
    
    if (activeAccounts.length === 0) {
      stopCampaignWorker();
      return;
    }

    // Find next lead
    const currentUser = JSON.parse(localStorage.getItem('cr_pro_auth_user_v2') || '{}');
    if (!currentUser.id) return;
    
    const leads = JSON.parse(localStorage.getItem(`cr_leads_${currentUser.id}`) || '[]');
    const pendingLeads = leads.filter((l: any) => {
      if (l.status !== LeadStatus.TO_SEND || !l.email) return false;
      try {
        const sentLeads = JSON.parse(localStorage.getItem('coldreach_sent_leads') || '[]');
        return !sentLeads.includes(l.id);
      } catch (e) {
        return true;
      }
    });

    if (pendingLeads.length === 0) {
      stopCampaignWorker();
      return;
    }

    const lead = pendingLeads[0];
    
    // Mark as sending immediately
    const updateLeadStatus = (id: string, status: string) => {
      const currentLeads = JSON.parse(localStorage.getItem(`cr_leads_${currentUser.id}`) || '[]');
      const updatedLeads = currentLeads.map((l: any) => l.id === id ? { ...l, status } : l);
      localStorage.setItem(`cr_leads_${currentUser.id}`, JSON.stringify(updatedLeads));
      window.dispatchEvent(new Event('cr_leads_updated'));
    };
    
    updateLeadStatus(lead.id, LeadStatus.SENDING);

    // Pick an account (Round-robin or least-sent)
    // Sort accounts by sent_count to pick the one that has sent the least
    const sortedAccounts = [...activeAccounts].sort((a, b) => (a.sent_count || 0) - (b.sent_count || 0));
    const acc = sortedAccounts.find((a: any) => (a.sent_count || 0) < (a.target_send || 50));
    
    if (!acc) {
      stopCampaignWorker();
      return;
    }

    const campaign = JSON.parse(localStorage.getItem(`cr_campaign_${currentUser.id}`) || '{}');
    const subject = campaign.subject || "Hello from ColdReach Pro";
    
    // Use basicReplace for consistent personalization
    const { basicReplace } = await import('./emailService.ts');
    const { result: personalizedSubject } = basicReplace(subject, lead);
    const { result: personalizedBody } = basicReplace(campaign.body || "", lead);

    // Add to activity log
    const addActivity = (msg: string, type: 'info' | 'success' | 'error' | 'reply' = 'info') => {
      const logs = JSON.parse(localStorage.getItem('cr_campaign_logs') || '[]');
      logs.unshift({ id: Date.now(), msg, type, time: new Date().toLocaleTimeString() });
      localStorage.setItem('cr_campaign_logs', JSON.stringify(logs.slice(0, 50)));
      window.dispatchEvent(new Event('cr_campaign_logs_updated'));
    };

    addActivity(`Sending to ${lead.email} using ${acc.email}...`);

    try {
      const response = await fetch('/.netlify/functions/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          access_token: acc.access_token,
          refresh_token: acc.refresh_token,
          expires_at: acc.expires_at,
          to: lead.email,
          subject: personalizedSubject,
          body: personalizedBody
        })
      });

      if (response.ok) {
        const data = await response.json();
        updateLeadStatus(lead.id, LeadStatus.SENT);
        addActivity(`Successfully sent to ${lead.email}`, 'success');
        
        try {
          const sentLeads = JSON.parse(localStorage.getItem('coldreach_sent_leads') || '[]');
          if (!sentLeads.includes(lead.id)) {
            sentLeads.push(lead.id);
            localStorage.setItem('coldreach_sent_leads', JSON.stringify(sentLeads));
          }
        } catch (e) {}

        const updatedAccounts = accounts.map((a: any) => {
          if (a.id === acc.id) {
            const newSentCount = (a.sent_count || 0) + 1;
            const newDeliveryCount = (a.delivery_count || 0) + 1;
            // Calculate reply rate based on sent count
            const replyCount = a.reply_count || 0;
            const newReplyRate = newSentCount > 0 ? Math.round((replyCount / newSentCount) * 100) : 0;

            return { 
              ...a, 
              sent_count: newSentCount,
              delivery_count: newDeliveryCount,
              reply_rate: newReplyRate,
              access_token: data.newAccessToken || a.access_token,
              expires_at: data.newExpiresAt || a.expires_at
            };
          }
          return a;
        });
        localStorage.setItem('coldreach_accounts', JSON.stringify(updatedAccounts));
        window.dispatchEvent(new Event('cr_accounts_updated'));
        
        // Update state
        localStorage.setItem('cr_campaign_state', JSON.stringify({
          ...state,
          lastSent: Date.now()
        }));
        window.dispatchEvent(new Event('cr_campaign_state_updated'));

        // Periodically check for replies (every 5 sends or so)
        const sendCount = JSON.parse(localStorage.getItem('cr_total_sends') || '0') + 1;
        localStorage.setItem('cr_total_sends', JSON.stringify(sendCount));
        
        if (sendCount % 5 === 0) {
          addActivity(`Checking for new replies across all accounts...`);
          for (const checkAcc of activeAccounts) {
            try {
              const replyRes = await fetch("/.netlify/functions/check-replies", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  access_token: checkAcc.access_token,
                  refresh_token: checkAcc.refresh_token,
                  expires_at: checkAcc.expires_at,
                }),
              });
              if (replyRes.ok) {
                const replyData = await replyRes.ok ? await replyRes.json() : null;
                if (replyData && replyData.replyCount > 0) {
                  addActivity(`Found ${replyData.replyCount} new replies for ${checkAcc.email}!`, 'reply');
                  
                  // Update account stats
                  const latestAccounts = JSON.parse(localStorage.getItem('coldreach_accounts') || '[]');
                  const updatedWithReplies = latestAccounts.map((a: any) => {
                    if (a.id === checkAcc.id) {
                      const newReplyCount = (a.reply_count || 0) + replyData.replyCount;
                      const sentCount = a.sent_count || 0;
                      const newReplyRate = sentCount > 0 ? Math.round((newReplyCount / sentCount) * 100) : 0;

                      return {
                        ...a,
                        reply_count: newReplyCount,
                        reply_rate: newReplyRate,
                        access_token: replyData.newAccessToken || a.access_token,
                        expires_at: replyData.newExpiresAt || a.expires_at
                      };
                    }
                    return a;
                  });
                  localStorage.setItem('coldreach_accounts', JSON.stringify(updatedWithReplies));
                  window.dispatchEvent(new Event('cr_accounts_updated'));

                  // Store replies for UI
                  const existingReplies = JSON.parse(localStorage.getItem('cr_new_replies') || '[]');
                  const newReplies = [...existingReplies, ...replyData.replies.map((r: any) => ({ ...r, accountEmail: checkAcc.email }))];
                  localStorage.setItem('cr_new_replies', JSON.stringify(newReplies));
                  window.dispatchEvent(new Event('cr_new_replies_updated'));
                }
              }
            } catch (e) {}
          }
        }
      } else {
        const errorData = await response.json();
        addActivity(`Failed to send to ${lead.email}: ${errorData.error || 'Unknown error'}`, 'error');
        updateLeadStatus(lead.id, LeadStatus.TO_SEND);
      }
    } catch (err) {
      if (!navigator.onLine) {
        addActivity(`Device offline. Paused sending to ${lead.email}. Will resume when online.`, 'info');
      } else {
        addActivity(`Temporary issue sending to ${lead.email}. Retrying...`, 'info');
      }
      console.error("Failed to send email via worker", err);
      updateLeadStatus(lead.id, LeadStatus.TO_SEND);
    }
  };

  runWorker();
  workerInterval = setInterval(runWorker, 5000);
};

export const stopCampaignWorker = () => {
  if (workerInterval) {
    clearInterval(workerInterval);
    workerInterval = null;
  }
  const state = JSON.parse(localStorage.getItem('cr_campaign_state') || '{}');
  localStorage.setItem('cr_campaign_state', JSON.stringify({
    ...state,
    running: false
  }));
  window.dispatchEvent(new Event('cr_campaign_state_updated'));
};
